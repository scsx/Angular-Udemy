# Course project final

Original finished project from Max, by the end of section 23

Firebase access has been updated to my account

Ready for any new section